# YT CREATOR HINDI — Phone-only build guide

1. Download and extract this ZIP.
2. Create a GitHub repository named `yt-creator-hindi` and set it to Private.
3. Upload the extracted project while preserving folder paths, including `.github/workflows/build-apk.yml` at repository root and the `android-wrapper/` folder. If your phone's GitHub upload page cannot preserve folders, stop and ask for an alternate upload method rather than uploading a broken structure.
4. Open the repository's Actions tab. Enable Actions if prompted.
5. Select `Build YT CREATOR HINDI APK` and press `Run workflow`, or push a commit to `main`.
6. Open the finished workflow run. If it is green, find Artifacts and download `YT-Creator-Hindi-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Tap the APK and follow Android's install prompts. Allow installation from that browser/file manager only if you trust the file; disable that permission afterward.

This creates a test/debug APK only. OTP, live payments, server video upload, real admin unlocking, live AI, and production monetization are not implemented yet. Do not use the demo for collecting real payments.

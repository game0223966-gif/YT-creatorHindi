# YT CREATOR HINDI

Android WebView wrapper project for the YT CREATOR HINDI editing-learning app.

## Included
- Course-focused interface and offline CapCut help guide.
- WhatsApp Help Center using the owner-provided contact link.
- ₹19 / 1-day and ₹499 / 1-month plan display; payment inquiries open WhatsApp.
- No learner video-upload feature or fake OTP/admin demo UI.

## Build
Open `android-wrapper` in Android Studio or use the included GitHub Actions workflow to build a debug APK.

## Before public launch
This source is not a production-ready service by itself. Add secure real authentication, server-side payment verification and cross-device access control, hosted lesson videos, privacy/terms/refund policies, and test on real devices before distributing to users.

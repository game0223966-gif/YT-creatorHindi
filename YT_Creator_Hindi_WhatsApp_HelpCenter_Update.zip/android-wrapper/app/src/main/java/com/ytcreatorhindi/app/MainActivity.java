package com.ytcreatorhindi.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState); requestWindowFeature(Window.FEATURE_NO_TITLE);
  // Blocks normal Android screenshots and most recordings/casting for this window.
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
  getWindow().setStatusBarColor(Color.rgb(10,10,13)); getWindow().setNavigationBarColor(Color.rgb(10,10,13));
  WebView web=new WebView(this); web.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
  web.setBackgroundColor(Color.rgb(9,9,12)); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setAllowFileAccess(false); s.setAllowContentAccess(false); s.setJavaScriptCanOpenWindowsAutomatically(false); s.setSupportMultipleWindows(false);
  web.setLongClickable(false); web.setHapticFeedbackEnabled(false); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
  web.setDownloadListener(new DownloadListener(){ @Override public void onDownloadStart(String url,String userAgent,String contentDisposition,String mimetype,long contentLength){Toast.makeText(MainActivity.this,"Downloads are disabled in this app.",Toast.LENGTH_SHORT).show();}});
  setContentView(web); web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){super.onBackPressed();}
}

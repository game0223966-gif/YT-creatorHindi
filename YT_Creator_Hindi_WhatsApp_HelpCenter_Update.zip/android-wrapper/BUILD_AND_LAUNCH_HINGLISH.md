# Updated build guide
1. Extract ZIP.
2. Upload the contents of `android-wrapper` to the root of a GitHub repository.
3. Open Actions and run Build Android APK.
4. Download `YT-Creator-Hindi-debug-apk` from the successful run's Artifacts.
5. This is a debug APK, not a Play Store release-signed build.

Security: FLAG_SECURE blocks normal Android screenshots and most screen recording/casting; filming the screen with another device cannot be completely prevented.

Agent is an offline FAQ; actual tutorial videos, OTP, payment, upload publishing, monetization and secure admin require further integrations/backend.

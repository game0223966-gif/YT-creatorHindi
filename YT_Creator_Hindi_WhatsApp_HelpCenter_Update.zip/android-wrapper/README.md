# YT CREATOR HINDI — upgraded Android starter

## Included
- Premium dark red/black UI; course cards and progress
- ₹19 / 7-day and ₹199 / monthly pricing screens
- Demo coupons and Admin Preview
- Offline Creator Help Agent with selected CapCut/YouTube tips (not live AI)
- Creator Studio demo profile, upload form preview and monetization status
- Android FLAG_SECURE to block normal screenshots and most screen recording/casting for the app window
- WebView downloads, long-click and Android backup disabled
- GitHub Actions workflow for a debug APK build

## Not live yet
OTP sends no SMS; payments do not charge money; coupon/admin are demo-only; video upload only previews a local file; monetization/payout does not exist; tutorial steps are written guides and actual video files/streaming URLs are not included; agent is offline FAQ not a live AI model.

## Security limits
FLAG_SECURE blocks normal Android screenshots and most recordings/casting for this app window but cannot stop someone filming with another device or guarantee every OEM/OS path is blocked. Paid videos should be hosted and streamed with server authorization, never shipped as downloadable APK assets.

## Production requirements
Secure backend and user roles; real OTP provider; verified payment gateway with server-side signature/webhook checks; server-validated coupon rules; private video streaming; upload moderation/copyright checks; creator identity/age checks and payout provider; privacy, terms, refund/cancellation policy; testing and release signing. Do not enable auto-renewal without explicit consent.

# YT CREATOR HINDI — Build guide (Hinglish)

## Is package mein kya hai?
- `index.html`: mobile par khulne wala clickable app prototype.
- `android-wrapper/`: Android Studio WebView wrapper ka basic source.
- UI mein Home, Courses, My Learning, Plans, Phone Login demo, Coupon demo aur Admin Preview hain.

## Phone par abhi kaise test karein?
1. ZIP extract karein.
2. `index.html` ko phone ke browser mein open karein.
3. Courses, lesson completion, coupon demo aur plans screens test karein.

## APK banane ke liye
1. Android Studio wale computer ki zaroorat hogi, ya kisi trusted cloud Android build service ka use karna hoga.
2. `android-wrapper` ko Android Studio project ke roop mein complete/configure karein, Gradle files aur app icon add karein.
3. `index.html` ko Android project ke `app/src/main/assets/` folder mein copy karein.
4. Debug build banakar phone par test karein; release ke liye app signing karein.

## Security aur live services
- OTP button abhi demo hai (screen par demo OTP `123456`); real SMS nahi bhejta.
- Payment buttons sirf demo message dikhate hain; paise charge nahi hote.
- Coupon codes browser-local demo hain; user unhein inspect/bypass kar sakta hai.
- Admin Preview secured nahi hai; ise real users ke liye deploy na karein.
- Live release se pehle secure backend, authentication, verified payment gateway, webhook/signature checks, coupon validation aur private video access lagana zaroori hai.
- Real photos/videos add karte waqt apne ya licensed assets use karein.

## Pricing
Requested plan: ₹19 / 7-day trial, ₹199 / one month. Trial auto-renewal ko user ki clear consent ke bina enable na karein.


## Android APK build workflow
Android SDK/Gradle build tools is environment mein available nahi the, isliye yahan signed/compiled APK generate nahi kiya ja saka. `android-wrapper` folder mein ab Gradle project aur GitHub Actions workflow hai. Is folder ke contents GitHub repo mein upload karke Actions run karne par test/debug APK artifact milega. Is process ko live OTP/payment enable samajhna nahi chahiye.

# YT CREATOR HINDI — Android app starter

This package contains:
- `index.html`: responsive, interactive mobile-first course app prototype.
- `android-wrapper/`: minimal Android WebView wrapper source files.
- `BUILD_AND_LAUNCH_HINGLISH.md`: next steps and important integration notes.

## Important status
This is a prototype/starter project, NOT a signed, production APK. It does not currently send real SMS OTPs or accept real payments. Coupon and admin actions are demo-only and stored locally in the browser. Do not use the demo admin panel to protect real content.

Before launch, add:
1. Backend authentication and authorization.
2. SMS OTP provider/Firebase Authentication and app configuration.
3. A verified payment gateway with server-side order creation, signature/webhook validation, refunds and subscription/access logic.
4. Server-side coupon validation, expiry/usage limits and secure admin roles.
5. Hosted course videos and licensed photos; do not rely on localStorage for paid access.
6. Privacy policy, terms, refund/cancellation policy and required legal/business verification.
7. Android release signing, testing and Play Console setup if publishing on Google Play.

Pricing in the prototype follows the requested plan: ₹19 for 7-day access and ₹199 for one month. Confirm whether the trial renews automatically before enabling any recurring billing.
